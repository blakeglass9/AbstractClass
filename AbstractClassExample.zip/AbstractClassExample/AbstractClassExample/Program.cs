﻿using System;

namespace AbstractClassExample
{
    class Program
    {
        static void Main(string[] args)
        {
            // Instantiate an Employee object and set the first and last names
            Employee employee = new Employee
            {
                FirstName = "Sample",  // Set the first name
                LastName = "Student"   // Set the last name
            };

            // Call the SayName method, which displays the full name
            employee.SayName();

            // Pause to allow the user to see the output before the program closes
            Console.ReadKey();
        }
    }
}
