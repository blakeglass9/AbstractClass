﻿using System;

namespace AbstractClassExample
{
    // Define an abstract class Person with properties and an abstract method
    public abstract class Person
    {
        // Property to store the first name
        public string FirstName { get; set; }

        // Property to store the last name
        public string LastName { get; set; }

        // Abstract method to say the person's name
        public abstract void SayName();
    }
}
