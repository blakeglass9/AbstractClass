﻿using System;

namespace AbstractClassExample
{
    // Define the Employee class that inherits from Person
    public class Employee : Person
    {
        // Implement the SayName method to display the full name
        public override void SayName()
        {
            Console.WriteLine("Name: " + FirstName + " " + LastName);
        }
    }
}
